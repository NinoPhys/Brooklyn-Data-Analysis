#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>
#include <iostream>
#include <cstdlib>
#include <string>
#include <math.h>
#include <fstream>
#include <sstream>
#include <vector>
#define NSAMPLING 1024

using namespace std;

int main() {

    ifstream myReadFile; 
    string skipchecker; //A line of the File
    string temp;    //Single value
    stringstream stream;    //Stream to navigate string fileline
    vector<string> v;   //Vector of strings containing all the values (aka, temp)
    double values[1024]; //Vector containing the values converted to double
    int channel=0;
    int pos=316333;
    myReadFile.open("Waveform.dat");
    
    if (myReadFile.is_open()) { //Al momento distingue solo canali, non eventi -> implementare variabile di conteggio per separare eventi
        //while (!myReadFile.eof()) {
        myReadFile.seekg(pos);
        while(channel<16){
            getline(myReadFile,  skipchecker); //write the line from file to string fileline
            if(skipchecker.find('=')==0){  //ignore lines which do not contain amplitude data
                skipchecker.clear();
                channel--;
            }
            else{
                stringstream stream(skipchecker);
                while (getline(stream, temp, ' ')) {    //Values in line are separated by space (' ')
 
                // store token string in the vector
                 v.push_back(temp); //add value (still as string) to vector<string> temp
                }
                if(v.size()==NSAMPLING+1){v.erase(v.end());}    //Sometimes, the program will a read an empty entry at the end. Delete that entry

                // print the vector

                for (int i = 0; i < v.size(); i++) { //Convert vector<string> to array of double
                    values[i]=stod(v[i]);
                    cout << i+1 << "\t" << v[i] << " " << values[i] << endl;
                }

                cout<< "channel" << channel + 1 << endl;
                v.clear();
                }

            channel++;
            if(channel==17){
                channel=1; //Reset the channel count
            }       
        }
    }
    pos = myReadFile.tellg();
    cout << pos << endl;
    //Last clears and file closing, to prevent memory leaks
    v.clear();
    skipchecker.clear();
    myReadFile.close();
    return 0;
}